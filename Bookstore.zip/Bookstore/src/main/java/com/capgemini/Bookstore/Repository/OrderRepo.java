package com.capgemini.Bookstore.Repository;

import com.capgemini.Bookstore.bean.Order;

public interface OrderRepo {
	
	public Order viewAllDetailedOrder();
	

}
