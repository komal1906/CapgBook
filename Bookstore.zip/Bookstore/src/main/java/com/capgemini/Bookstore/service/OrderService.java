package com.capgemini.Bookstore.service;

import com.capgemini.Bookstore.bean.Order;

public interface OrderService {
	
	Order viewAllDetailedOrder();
	

}
