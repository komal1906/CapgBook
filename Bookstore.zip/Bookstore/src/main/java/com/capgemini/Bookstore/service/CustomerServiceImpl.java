package com.capgemini.Bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.BookRepo;
import com.capgemini.Bookstore.Repository.CustomerRepo;
import com.capgemini.Bookstore.bean.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

	
	@Autowired
	CustomerRepo customerrp;
	@Override
	public Customer viewProfileDetails() {
		
		return customerrp.viewProfileDetails();
	}

	@Override
	public Customer updateProfileDetails() {
		
		return customerrp.updateProfileDetails();
	}

}
