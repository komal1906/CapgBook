package com.capgemini.Bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.AdminRepo;
import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;

@Service
public class BookServiceImpl implements BookService {

	
	@Autowired
	AdminRepo adminrp;
	
	@Override
	public List<Book> specificCategory() {
	
		return null;
	}

	@Override
	public List<Book> mostRecentPublishedBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> viewBestSellingBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> mostFavouredBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BookReview> viewAllCustomerReview() {
		// TODO Auto-generated method stub
		return null;
	}

}
