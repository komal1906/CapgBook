package com.capgemini.Bookstore.service;

import com.capgemini.Bookstore.bean.Cart;

public interface CartService {
	
	Cart removeCart();
	Cart addBookToCart();
	Cart updateQuantity();
	
	

}
