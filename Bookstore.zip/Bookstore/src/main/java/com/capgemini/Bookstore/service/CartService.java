package com.capgemini.Bookstore.service;

import com.capgemini.Bookstore.bean.Cart;

public interface CartService {
	
	public Cart removeCart();
	public Cart addBookToCart();
	public Cart updateQuantity();
	
	

}
