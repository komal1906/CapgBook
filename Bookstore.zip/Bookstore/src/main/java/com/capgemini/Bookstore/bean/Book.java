package com.capgemini.Bookstore.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "bookdetail")
public class Book {

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookId;
	@NotNull
	private String bookTitle;
	@NotNull
	private String bookAuthor;
	private String bookDesc;
	@NotNull
	private String bookISBNo;
	@NotNull
	private float bookPrice;
	@NotNull
	private Date bookPublishDate;
	@NotNull
	private int bookQuantity;
	private Category bookCategory;
	@NotNull
	private String bookImage;
	
	
	
	
	
	
}
