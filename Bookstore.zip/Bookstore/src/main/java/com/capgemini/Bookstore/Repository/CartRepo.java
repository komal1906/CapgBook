package com.capgemini.Bookstore.Repository;

import com.capgemini.Bookstore.bean.Cart;

public interface CartRepo {
	
	Cart removeCart();
	Cart addBookToCart();
	Cart updateQuantity();
	
	

}
