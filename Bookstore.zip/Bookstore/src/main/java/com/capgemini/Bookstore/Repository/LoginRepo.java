package com.capgemini.Bookstore.Repository;

public interface LoginRepo {
	
	boolean addAdmin();
	boolean addCustomer();
	

}
