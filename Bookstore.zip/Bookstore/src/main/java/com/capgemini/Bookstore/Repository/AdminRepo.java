package com.capgemini.Bookstore.Repository;

import java.util.List;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;
import com.capgemini.Bookstore.bean.Category;
import com.capgemini.Bookstore.bean.Customer;
import com.capgemini.Bookstore.bean.Order;

public interface AdminRepo {

	List<Customer> viewAllCustomer();
	Admin addAdmin();
	Admin deleteAdmin();
	Admin updateAdmin();
	List<Category> viewAllCategories();
	Category createCategory();
	List<Category> deleteCategories();
	List<Category> updateCategories();
	List<Book> viewAllBook();
	List<Book> deleteBook();
	Book addBook();
	Book updateBook();
	Customer createCustomer();
	List<Customer> deleteCustomer();
	Customer updateCustomer();
	List<BookReview> viewAllReviews();
	List<BookReview> deleteReview();
	BookReview updateReview();
	List<Order> viewAllOrders();
	Order updateOrder();
	Order deleteOrder();
	
	
}
