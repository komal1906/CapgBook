package com.capgemini.Bookstore.Repository;

import java.util.List;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;
import com.capgemini.Bookstore.bean.Category;
import com.capgemini.Bookstore.bean.Customer;
import com.capgemini.Bookstore.bean.Order;

public interface AdminRepo {

	public List<Customer> viewAllCustomer();
	public Admin addAdmin();
	public Admin deleteAdmin();
	public Admin updateAdmin();
	public List<Category> viewAllCategories();
	public Category createCategory();
	public List<Category> deleteCategories();
	public List<Category> updateCategories();
	public List<Book> viewAllBook();
	public List<Book> deleteBook();
	public Book addBook();
	public Book updateBook();
	public Customer createCustomer();
	public List<Customer> deleteCustomer();
	public Customer updateCustomer();
	public List<BookReview> viewAllReviews();
	public List<BookReview> deleteReview();
	public BookReview updateReview();
	public List<Order> viewAllOrders();
	public Order updateOrder();
	public Order deleteOrder();
	
	
}
