package com.capgemini.Bookstore.service;

public interface LoginService {
	
	boolean addAdmin();
	boolean addCustomer();
	

}
