package com.capgemini.Bookstore.service;

public interface LoginService {
	
	public boolean addAdmin();
	public boolean addCustomer();
	

}
