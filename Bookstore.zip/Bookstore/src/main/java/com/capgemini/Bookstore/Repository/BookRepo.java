package com.capgemini.Bookstore.Repository;

import java.util.List;

import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;

public interface BookRepo {
	
	List<Book> specificCategory();
	List<Book> mostRecentPublishedBook();
	List<Book> viewBestSellingBook();
	List<Book> mostFavouredBook();
	List<BookReview> viewAllCustomerReview();
	

}
