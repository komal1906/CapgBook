package com.capgemini.Bookstore.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "orderdetail")
public class OrderDetails {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderDetailId;
	private Order orderId;
	private Book bookId;
	private int subtotal;
	private int orderQuantity;
	

}
