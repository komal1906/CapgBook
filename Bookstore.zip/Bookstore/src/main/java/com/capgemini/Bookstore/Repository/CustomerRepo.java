package com.capgemini.Bookstore.Repository;

import com.capgemini.Bookstore.bean.Customer;

public interface CustomerRepo {
	
	public Customer viewProfileDetails();
	public Customer updateProfileDetails();
	
}
