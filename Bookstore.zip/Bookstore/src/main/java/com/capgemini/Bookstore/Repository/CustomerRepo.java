package com.capgemini.Bookstore.Repository;

import com.capgemini.Bookstore.bean.Customer;

public interface CustomerRepo {
	
	Customer viewProfileDetails();
	Customer updateProfileDetails();
	
}
