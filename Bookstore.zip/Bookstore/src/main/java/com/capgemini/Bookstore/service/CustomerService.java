package com.capgemini.Bookstore.service;

import com.capgemini.Bookstore.bean.Customer;

public interface CustomerService {
	
	Customer viewProfileDetails();
	Customer updateProfileDetails();
	
}
